package com.securevoting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecureVotingBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
